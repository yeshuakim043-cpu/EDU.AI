# **App Name**: CognitoEdu

## Core Features:

- Content Ingestion & AI Analysis: Upload diverse learning materials (PDFs, images, documents, web links, etc.). The AI will process content, extract key information, and convert it for learning tool generation.
- Secure User & Account Management: Robust authentication system supporting email/password and Google Sign-In. Includes user profiles for students and teachers with distinct roles and cloud synchronization of data.
- AI-Powered Study Tool Generation: Leverage AI to automatically generate essential interactive study tools like flashcards and basic multiple-choice quizzes from uploaded and analyzed learning materials.
- Personalized Learning Dashboard: A central, intuitive dashboard for users to access their personal learning materials, view generated study tools, track basic progress, and see personalized recommendations based on usage.
- Basic Classroom Functionality: Teachers can create virtual classrooms and invite students using a unique code. Students can join classrooms, access shared learning materials, and view teacher announcements.
- Interactive Quizzing & Progress Tracking: Enable students to take AI-generated quizzes and track their scores and completion status. Provides basic insights into quiz performance.

## Style Guidelines:

- Scheme: Light mode, promoting clarity and reducing eye strain for extended study sessions.
- Primary Color: Modern purple (#6633CC), suggesting innovation and focus, while being visually distinct and harmonious on a light background.
- Background Color: Subtly desaturated light purple (#F2EFF7), providing a clean canvas that complements the primary color.
- Accent Color: Vibrant cyan-blue (#2480A3), used for key calls to action and highlights, offering a refreshing contrast and guidance through the interface.
- Headlines and Body text: 'Inter' (sans-serif), chosen for its modern, neutral, and highly readable characteristics across various content types, suitable for both short UI elements and longer text blocks.
- Utilize a set of modern, clear line icons. Icons should visually communicate function without overwhelming the 'student-friendly' and 'less stressful' aesthetic.
- Mobile-first responsive design, ensuring a seamless experience across all devices. Dashboards will prioritize key learning activities and progress at a glance.
- Incorporate smooth, subtle animations for transitions and feedback on user actions, enhancing the 'futuristic UI' feel without being distracting.