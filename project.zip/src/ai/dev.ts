
import { config } from 'dotenv';
config();

import '@/ai/flows/summarize-and-extract-key-concepts.ts';
import '@/ai/flows/generate-study-tools-from-content.ts';
import '@/ai/flows/generate-educational-video.ts';
