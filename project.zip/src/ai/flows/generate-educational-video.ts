
'use server';
/**
 * @fileOverview A Genkit flow for generating educational videos using the Veo 3 model.
 * 
 * - generateEducationalVideo - A function that triggers video generation from text content.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';
import { googleAI } from '@genkit-ai/google-genai';

export const maxDuration = 120; // Increase server action timeout to 2 minutes

const GenerateVideoInputSchema = z.object({
  topic: z.string().describe('The topic or description of the video to be generated.'),
});
export type GenerateVideoInput = z.infer<typeof GenerateVideoInputSchema>;

const GenerateVideoOutputSchema = z.object({
  videoDataUri: z.string().describe('The generated video as a data URI.'),
});
export type GenerateVideoOutput = z.infer<typeof GenerateVideoOutputSchema>;

export async function generateEducationalVideo(input: GenerateVideoInput): Promise<GenerateVideoOutput> {
  return generateVideoFlow(input);
}

const generateVideoFlow = ai.defineFlow(
  {
    name: 'generateEducationalVideoFlow',
    inputSchema: GenerateVideoInputSchema,
    outputSchema: GenerateVideoOutputSchema,
  },
  async (input) => {
    let { operation } = await ai.generate({
      model: googleAI.model('veo-3.0-generate-preview'),
      prompt: `Create a professional educational animation about ${input.topic}. Use clear visuals and smooth transitions to explain the core concepts clearly.`,
      config: {
        aspectRatio: '16:9',
      },
    });

    if (!operation) {
      throw new Error('Failed to start video generation operation');
    }

    while (!operation.done) {
      operation = await ai.checkOperation(operation);
      if (!operation.done) {
        await new Promise((resolve) => setTimeout(resolve, 5000));
      }
    }

    if (operation.error) {
      throw new Error('Failed to generate video: ' + operation.error.message);
    }

    const videoPart = operation.output?.message?.content.find((p) => !!p.media);
    if (!videoPart || !videoPart.media) {
      throw new Error('No video media found in operation output');
    }

    const apiKey = process.env.GEMINI_API_KEY || process.env.GOOGLE_GENERATIVE_AI_API_KEY || process.env.GOOGLE_GENAI_API_KEY;
    const videoUrl = videoPart.media.url;
    
    try {
      const response = await fetch(`${videoUrl}&key=${apiKey}`);
      if (!response.ok) throw new Error('Failed to download video content');
      
      const buffer = await response.arrayBuffer();
      const base64 = Buffer.from(buffer).toString('base64');
      
      return {
        videoDataUri: `data:video/mp4;base64,${base64}`,
      };
    } catch (err) {
      console.error('Video transfer error:', err);
      // Fallback to the temporary URL if download fails (might have CORS issues in some browsers)
      return {
        videoDataUri: videoUrl,
      };
    }
  }
);
