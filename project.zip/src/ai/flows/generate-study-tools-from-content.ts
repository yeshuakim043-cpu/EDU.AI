'use server';
/**
 * @fileOverview A Genkit flow for generating study tools (flashcards and multiple-choice quizzes)
 * from various learning materials like text or images.
 *
 * - generateStudyTools - A function that orchestrates the study tool generation process.
 * - GenerateStudyToolsFromContentInput - The input type for the generateStudyTools function.
 * - GenerateStudyToolsFromContentOutput - The return type for the generateStudyTools function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const FlashcardSchema = z.object({
  term: z.string().describe('The term for the flashcard.'),
  definition: z.string().describe('The definition for the flashcard.'),
});

const MultipleChoiceQuestionSchema = z.object({
  question: z.string().describe('The question for the multiple-choice quiz.'),
  options: z.array(z.string()).min(2).describe('An array of possible answers for the question. Must contain at least two options.'),
  correctAnswer: z.string().describe('The correct answer for the question, which must be one of the options.'),
});

const GenerateStudyToolsFromContentInputSchema = z.object({
  textContent: z.string().optional().describe('The textual content of the learning material.'),
  mediaDataUri:
    z.string().optional().describe(
      "An image of the learning material, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});
export type GenerateStudyToolsFromContentInput = z.infer<typeof GenerateStudyToolsFromContentInputSchema>;

const GenerateStudyToolsFromContentOutputSchema = z.object({
  flashcards: z.array(FlashcardSchema).describe('A list of flashcards generated from the content.'),
  multipleChoiceQuiz: z.array(MultipleChoiceQuestionSchema).describe('A list of multiple-choice questions generated from the content.'),
});
export type GenerateStudyToolsFromContentOutput = z.infer<typeof GenerateStudyToolsFromContentOutputSchema>;

export async function generateStudyTools(input: GenerateStudyToolsFromContentInput): Promise<GenerateStudyToolsFromContentOutput> {
  return generateStudyToolsFlow(input);
}

const generateStudyToolsPrompt = ai.definePrompt({
  name: 'generateStudyToolsPrompt',
  input: { schema: GenerateStudyToolsFromContentInputSchema },
  output: { schema: GenerateStudyToolsFromContentOutputSchema },
  prompt: `You are an AI assistant specialized in creating study tools from learning materials. Your task is to analyze the provided content and generate a set of flashcards (term-definition pairs) and a simple multiple-choice quiz.

Here is the learning material:
{{#if textContent}}
Text Content: {{{textContent}}}
{{/if}}
{{#if mediaDataUri}}
Image Content: {{media url=mediaDataUri}}
{{/if}}

If both text and image content are provided, prioritize the image content for analysis unless the text content provides additional context not easily discernible from the image.

Generate the output in JSON format, strictly adhering to the following schema:
{{jsonSchema GenerateStudyToolsFromContentOutputSchema}}`,
});

const generateStudyToolsFlow = ai.defineFlow(
  {
    name: 'generateStudyToolsFlow',
    inputSchema: GenerateStudyToolsFromContentInputSchema,
    outputSchema: GenerateStudyToolsFromContentOutputSchema,
  },
  async (input) => {
    const { output } = await generateStudyToolsPrompt(input);
    if (!output) {
      throw new Error('Failed to generate study tools: output is null or undefined.');
    }
    return output;
  }
);
