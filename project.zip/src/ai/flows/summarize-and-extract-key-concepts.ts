'use server';
/**
 * @fileOverview An AI agent that summarizes learning documents and extracts key concepts.
 *
 * - summarizeAndExtractKeyConcepts - A function that handles the summarization and key concept extraction process.
 * - SummarizeAndExtractKeyConceptsInput - The input type for the summarizeAndExtractKeyConcepts function.
 * - SummarizeAndExtractKeyConceptsOutput - The return type for the summarizeAndExtractKeyConcepts function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SummarizeAndExtractKeyConceptsInputSchema = z.object({
  documentContent: z
    .string()
    .describe(
      'The text content of the learning material to be summarized and from which key concepts will be extracted.'
    )
});
export type SummarizeAndExtractKeyConceptsInput = z.infer<
  typeof SummarizeAndExtractKeyConceptsInputSchema
>;

const SummarizeAndExtractKeyConceptsOutputSchema = z.object({
  summary: z.string().describe('A concise summary of the provided document content.'),
  keyConcepts: z.array(z.string()).describe('A list of important key concepts extracted from the document.')
});
export type SummarizeAndExtractKeyConceptsOutput = z.infer<
  typeof SummarizeAndExtractKeyConceptsOutputSchema
>;

export async function summarizeAndExtractKeyConcepts(
  input: SummarizeAndExtractKeyConceptsInput
): Promise<SummarizeAndExtractKeyConceptsOutput> {
  return summarizeAndExtractKeyConceptsFlow(input);
}

const summarizeAndExtractKeyConceptsPrompt = ai.definePrompt({
  name: 'summarizeAndExtractKeyConceptsPrompt',
  input: {schema: SummarizeAndExtractKeyConceptsInputSchema},
  output: {schema: SummarizeAndExtractKeyConceptsOutputSchema},
  prompt: `As an AI assistant for students, your task is to analyze the provided learning material.

First, generate a concise summary of the document, highlighting the main ideas and overall purpose.

Second, identify and list the most important key concepts and terms from the document. These should be distinct and fundamental to understanding the material.

Ensure the output is strictly in JSON format matching the following schema:
{{json output.schema}}

Document Content:
{{{documentContent}}}`,
});

const summarizeAndExtractKeyConceptsFlow = ai.defineFlow(
  {
    name: 'summarizeAndExtractKeyConceptsFlow',
    inputSchema: SummarizeAndExtractKeyConceptsInputSchema,
    outputSchema: SummarizeAndExtractKeyConceptsOutputSchema,
  },
  async (input) => {
    const {output} = await summarizeAndExtractKeyConceptsPrompt(input);
    return output!;
  }
);
