import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Plus, Users, BookOpen, Clock, Calendar, MessageSquare, ArrowUpRight } from "lucide-react";
import Link from "next/link";

export default function ClassroomsPage() {
  return (
    <div className="max-w-7xl mx-auto space-y-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight">Classroom Hub</h1>
          <p className="text-muted-foreground font-medium mt-1">Connect with your teachers and fellow students.</p>
        </div>
        <div className="flex gap-2">
           <Button variant="outline" className="rounded-xl font-bold h-11 border-2" asChild>
              <Link href="/dashboard/classrooms/join">Join Class</Link>
           </Button>
           <Button className="rounded-xl font-bold h-11 shadow-lg shadow-primary/20">
              <Plus className="w-4 h-4 mr-2" />
              Create Classroom
           </Button>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
         <ClassroomCard 
            title="AP Physics 2"
            teacher="Mr. Anderson"
            students={24}
            nextAssignment="Midterm Prep Quiz"
            dueDate="In 2 days"
            color="bg-blue-600"
         />
         <ClassroomCard 
            title="Advanced Spanish"
            teacher="Sra. Rodriguez"
            students={18}
            nextAssignment="Speaking Practice"
            dueDate="Tomorrow"
            color="bg-emerald-600"
         />
         <ClassroomCard 
            title="Modern World History"
            teacher="Dr. Thompson"
            students={32}
            nextAssignment="Research Paper Outline"
            dueDate="Next Friday"
            color="bg-purple-600"
         />
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
         <section className="lg:col-span-2 space-y-4">
            <h2 className="text-2xl font-bold">Recent Announcements</h2>
            <div className="space-y-4">
               <Announcement 
                  author="Mr. Anderson"
                  content="Don't forget to review the study guide for the upcoming exam. I've uploaded the practice problems!"
                  time="2 hours ago"
               />
               <Announcement 
                  author="Sra. Rodriguez"
                  content="The conversation lab is open today for extra practice before our speaking assessments."
                  time="Yesterday"
               />
            </div>
         </section>

         <section className="space-y-4">
            <h2 className="text-2xl font-bold">Classroom Activity</h2>
            <Card className="rounded-3xl border-none shadow-sm ring-1 ring-border">
               <CardContent className="p-6 space-y-6">
                  <ActivityItem 
                     icon={<MessageSquare className="w-4 h-4" />}
                     label="Study Room Active"
                     description="3 classmates are studying Physics"
                  />
                  <ActivityItem 
                     icon={<Calendar className="w-4 h-4" />}
                     label="Next Class"
                     description="AP Physics @ 10:30 AM"
                  />
                  <ActivityItem 
                     icon={<BookOpen className="w-4 h-4" />}
                     label="New Material"
                     description="History: Cold War Slides"
                  />
               </CardContent>
            </Card>
         </section>
      </div>
    </div>
  );
}

function ClassroomCard({ title, teacher, students, nextAssignment, dueDate, color }: any) {
  return (
    <Card className="rounded-3xl border-none shadow-md overflow-hidden hover:shadow-xl transition-all group border">
       <div className={`h-24 ${color} relative p-6`}>
          <div className="absolute top-0 right-0 p-4 opacity-10">
             <GraduationCap className="w-24 h-24" />
          </div>
          <h3 className="text-white font-black text-2xl leading-tight">{title}</h3>
       </div>
       <CardContent className="p-6 space-y-4">
          <div className="flex items-center gap-3">
             <Avatar className="w-8 h-8">
                <AvatarImage src={`https://picsum.photos/seed/${teacher}/100/100`} />
                <AvatarFallback>{teacher[0]}</AvatarFallback>
             </Avatar>
             <p className="text-sm font-bold">{teacher}</p>
          </div>
          
          <div className="space-y-3 pt-2">
             <div className="flex justify-between items-center text-sm font-medium">
                <div className="flex items-center gap-2 text-muted-foreground">
                   <Users className="w-4 h-4" />
                   {students} Students
                </div>
                <div className="flex items-center gap-2 text-muted-foreground">
                   <Clock className="w-4 h-4" />
                   {dueDate}
                </div>
             </div>
             <div className="p-3 bg-secondary rounded-xl text-sm font-bold border">
                <p className="text-xs text-muted-foreground font-black uppercase tracking-widest mb-1">Next Task</p>
                {nextAssignment}
             </div>
          </div>
       </CardContent>
       <CardFooter className="px-6 pb-6 pt-0">
          <Button className="w-full rounded-xl font-bold" variant="outline" asChild>
             <Link href={`/dashboard/classrooms/1`}>
                Enter Classroom
                <ArrowUpRight className="ml-2 w-4 h-4" />
             </Link>
          </Button>
       </CardFooter>
    </Card>
  );
}

function Announcement({ author, content, time }: any) {
  return (
    <div className="p-6 rounded-2xl bg-card border shadow-sm space-y-3">
       <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
             <Avatar className="w-8 h-8">
                <AvatarImage src={`https://picsum.photos/seed/${author}/100/100`} />
             </Avatar>
             <span className="font-bold">{author}</span>
          </div>
          <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">{time}</span>
       </div>
       <p className="text-muted-foreground font-medium leading-relaxed">{content}</p>
       <div className="flex gap-2">
          <Button variant="ghost" size="sm" className="text-primary font-bold">Reply</Button>
          <Button variant="ghost" size="sm" className="text-muted-foreground font-bold">Like</Button>
       </div>
    </div>
  );
}

function ActivityItem({ icon, label, description }: any) {
  return (
    <div className="flex gap-4 items-start">
       <div className="bg-primary/10 p-2 rounded-lg text-primary">
          {icon}
       </div>
       <div className="space-y-0.5">
          <p className="font-bold text-sm">{label}</p>
          <p className="text-xs text-muted-foreground font-medium">{description}</p>
       </div>
    </div>
  );
}

function GraduationCap(props: any) {
    return (
        <svg
            {...props}
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
        >
            <path d="M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.599 9.084a1 1 0 0 0-.01 1.838l8.57 3.906a2 2 0 0 0 1.66 0l8.57-3.906Z" />
            <path d="M6 13v4a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2v-4" />
        </svg>
    )
}