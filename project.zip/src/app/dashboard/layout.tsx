"use client";

import { SidebarProvider, Sidebar, SidebarContent, SidebarHeader, SidebarFooter, SidebarMenu, SidebarMenuItem, SidebarMenuButton, SidebarGroup, SidebarGroupLabel, SidebarInset, SidebarTrigger } from "@/components/ui/sidebar";
import { 
  LayoutDashboard, 
  Brain, 
  Trophy, 
  Settings, 
  LogOut,
  Sparkles,
  FileText,
  Gamepad2,
  GraduationCap,
  Zap
} from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  const navItems = [
    { icon: LayoutDashboard, label: "Dashboard", href: "/dashboard" },
    { icon: FileText, label: "Materials", href: "/dashboard/materials" },
    { icon: Brain, label: "AI Tutor", href: "/dashboard/tutor" },
    { icon: GraduationCap, label: "Classrooms", href: "/dashboard/classrooms" },
    { icon: Trophy, label: "Leaderboards", href: "/dashboard/leaderboards" },
    { icon: Gamepad2, label: "Games", href: "/dashboard/games" },
  ];

  return (
    <SidebarProvider>
      <Sidebar collapsible="icon" className="border-r border-white/5 bg-background shadow-2xl">
        <SidebarHeader className="p-6">
          <Link href="/dashboard" className="flex items-center gap-3">
            <div className="bg-primary p-2.5 rounded-2xl text-white shrink-0 shadow-[0_0_20px_rgba(147,51,234,0.4)]">
              <Sparkles className="w-5 h-5" />
            </div>
            <span className="font-black text-xl tracking-tighter group-data-[collapsible=icon]:hidden">EDU.AI</span>
          </Link>
        </SidebarHeader>
        <SidebarContent className="px-3">
          <SidebarGroup>
            <SidebarGroupLabel className="group-data-[collapsible=icon]:hidden uppercase text-[10px] tracking-[0.3em] font-black text-muted-foreground/50 mb-2 px-3">Ecosystem</SidebarGroupLabel>
            <SidebarMenu>
              {navItems.map((item) => (
                <SidebarMenuItem key={item.href}>
                  <SidebarMenuButton 
                    asChild 
                    isActive={pathname === item.href} 
                    tooltip={item.label}
                    className="h-12 px-4 rounded-xl transition-all duration-300 data-[active=true]:bg-primary/10 data-[active=true]:text-primary"
                  >
                    <Link href={item.href}>
                      <item.icon className={`w-5 h-5 ${pathname === item.href ? 'text-primary' : 'text-muted-foreground'}`} />
                      <span className="font-bold">{item.label}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroup>
          
          <SidebarGroup className="mt-auto px-3">
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton asChild tooltip="Settings" className="h-12 px-4 rounded-xl">
                  <Link href="/dashboard/settings">
                    <Settings className="w-5 h-5 text-muted-foreground" />
                    <span className="font-bold">Settings</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroup>
        </SidebarContent>
        <SidebarFooter className="p-6 border-t border-white/5">
          <div className="flex items-center gap-3 group-data-[collapsible=icon]:justify-center">
            <Avatar className="w-10 h-10 border-2 border-primary/20 ring-4 ring-primary/5 shadow-xl">
              <AvatarImage src="https://picsum.photos/seed/user1/100/100" />
              <AvatarFallback>JD</AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0 group-data-[collapsible=icon]:hidden">
              <p className="text-sm font-black truncate">Jane Doe</p>
              <p className="text-[10px] text-primary truncate font-black uppercase tracking-widest">Master Rank</p>
            </div>
            <button className="text-muted-foreground hover:text-destructive transition-colors group-data-[collapsible=icon]:hidden">
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </SidebarFooter>
      </Sidebar>
      <SidebarInset className="bg-background relative">
        <div className="absolute top-0 left-0 w-full h-[500px] bg-gradient-to-b from-primary/5 to-transparent pointer-events-none -z-10" />
        <header className="sticky top-0 z-20 flex h-20 shrink-0 items-center justify-between border-b border-white/5 bg-background/50 backdrop-blur-2xl px-8">
          <div className="flex items-center gap-6">
            <SidebarTrigger className="text-muted-foreground hover:text-primary transition-colors" />
            <div className="h-4 w-px bg-white/10 hidden sm:block" />
            <h2 className="text-sm font-black uppercase tracking-[0.2em] text-muted-foreground/80 hidden sm:block">
              {pathname.split('/').pop()?.replace('-', ' ') || 'Overview'}
            </h2>
          </div>
          <div className="flex items-center gap-4">
             <div className="flex items-center gap-2 bg-secondary/40 px-4 py-2 rounded-2xl border border-white/5 shadow-xl backdrop-blur-md">
                <Trophy className="w-4 h-4 text-primary" />
                <span className="text-xs font-black tracking-tighter">12,450 XP</span>
             </div>
             <div className="flex items-center gap-2 bg-orange-500/10 text-orange-500 px-4 py-2 rounded-2xl border border-orange-500/20 shadow-xl backdrop-blur-md">
                <Zap className="w-4 h-4 fill-orange-500 animate-pulse" />
                <span className="text-xs font-black italic tracking-tighter">14 DAY STREAK</span>
             </div>
          </div>
        </header>
        <main className="flex-1 p-8">
          {children}
        </main>
      </SidebarInset>
    </SidebarProvider>
  );
}
