import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Trophy, Medal, Star, Target, Zap, TrendingUp, Users } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function LeaderboardsPage() {
  const ranks = [
    { name: "Bronze", color: "bg-orange-200 text-orange-800" },
    { name: "Silver", color: "bg-gray-200 text-gray-800" },
    { name: "Gold", color: "bg-yellow-200 text-yellow-800" },
    { name: "Platinum", color: "bg-teal-200 text-teal-800" },
    { name: "Diamond", color: "bg-blue-200 text-blue-800" },
    { name: "Master", color: "bg-purple-200 text-purple-800" },
    { name: "Grandmaster", color: "bg-red-200 text-red-800" },
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-extrabold tracking-tight">Hall of Fame</h1>
        <p className="text-muted-foreground text-lg font-medium max-w-2xl mx-auto">
          The top learners this week. Climb the ranks by completing quizzes, staying consistent, and helping others.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
         {/* Top 3 Podium */}
         <div className="md:col-span-3 flex flex-col md:flex-row items-end justify-center gap-8 py-12">
            {/* Rank 2 */}
            <div className="flex flex-col items-center gap-4 order-2 md:order-1">
               <div className="relative">
                  <Avatar className="w-20 h-20 border-4 border-gray-300 shadow-xl">
                     <AvatarImage src="https://picsum.photos/seed/rank2/100/100" />
                     <AvatarFallback>S</AvatarFallback>
                  </Avatar>
                  <div className="absolute -bottom-2 -right-2 bg-gray-300 p-2 rounded-full text-gray-800 shadow-md">
                     <Medal className="w-4 h-4" />
                  </div>
               </div>
               <div className="text-center">
                  <p className="font-bold">Sarah Jenkins</p>
                  <p className="text-xs font-black text-muted-foreground uppercase tracking-widest">14,200 XP</p>
               </div>
               <div className="w-32 h-24 bg-gray-100 rounded-t-3xl border-x border-t flex items-center justify-center font-black text-3xl text-gray-400">2</div>
            </div>

            {/* Rank 1 */}
            <div className="flex flex-col items-center gap-4 order-1 md:order-2 scale-110">
               <div className="relative">
                  <div className="absolute -top-12 left-1/2 -translate-x-1/2 text-yellow-400 animate-bounce">
                     <Trophy className="w-12 h-12 fill-current" />
                  </div>
                  <Avatar className="w-24 h-24 border-4 border-yellow-400 shadow-2xl ring-4 ring-yellow-400/20">
                     <AvatarImage src="https://picsum.photos/seed/rank1/100/100" />
                     <AvatarFallback>M</AvatarFallback>
                  </Avatar>
                  <div className="absolute -bottom-2 -right-2 bg-yellow-400 p-2 rounded-full text-yellow-900 shadow-md">
                     <Star className="w-5 h-5 fill-current" />
                  </div>
               </div>
               <div className="text-center">
                  <p className="font-black text-lg">Marcus Lee</p>
                  <p className="text-xs font-black text-primary uppercase tracking-widest">18,500 XP</p>
               </div>
               <div className="w-40 h-32 bg-primary rounded-t-3xl shadow-xl flex items-center justify-center font-black text-5xl text-white">1</div>
            </div>

            {/* Rank 3 */}
            <div className="flex flex-col items-center gap-4 order-3">
               <div className="relative">
                  <Avatar className="w-16 h-16 border-4 border-orange-400 shadow-lg">
                     <AvatarImage src="https://picsum.photos/seed/rank3/100/100" />
                     <AvatarFallback>L</AvatarFallback>
                  </Avatar>
                  <div className="absolute -bottom-2 -right-2 bg-orange-400 p-1.5 rounded-full text-orange-950 shadow-md">
                     <Target className="w-3 h-3" />
                  </div>
               </div>
               <div className="text-center">
                  <p className="font-bold">Leo Garcia</p>
                  <p className="text-xs font-black text-muted-foreground uppercase tracking-widest">12,100 XP</p>
               </div>
               <div className="w-28 h-20 bg-orange-50 rounded-t-3xl border-x border-t flex items-center justify-center font-black text-2xl text-orange-300">3</div>
            </div>
         </div>
      </div>

      <Tabs defaultValue="global" className="w-full">
        <div className="flex justify-center mb-8">
           <TabsList className="rounded-2xl p-1 bg-secondary h-14">
             <TabsTrigger value="global" className="rounded-xl px-8 font-bold h-12 data-[state=active]:bg-white data-[state=active]:shadow-md">Global</TabsTrigger>
             <TabsTrigger value="classroom" className="rounded-xl px-8 font-bold h-12 data-[state=active]:bg-white data-[state=active]:shadow-md">Classroom</TabsTrigger>
             <TabsTrigger value="friends" className="rounded-xl px-8 font-bold h-12 data-[state=active]:bg-white data-[state=active]:shadow-md">Friends</TabsTrigger>
           </TabsList>
        </div>
        
        <TabsContent value="global" className="space-y-3">
           <LeaderboardItem rank={4} name="Jane Doe (You)" xp="12,450" trend="up" isUser />
           <LeaderboardItem rank={5} name="Alex River" xp="11,800" trend="down" />
           <LeaderboardItem rank={6} name="Emily Watson" xp="10,500" trend="up" />
           <LeaderboardItem rank={7} name="Thomas Shell" xp="9,200" trend="stable" />
        </TabsContent>
      </Tabs>

      <div className="grid md:grid-cols-2 gap-8 pt-8">
         <Card className="rounded-3xl border-none shadow-xl bg-gradient-to-br from-primary to-purple-700 text-white overflow-hidden">
            <CardHeader>
               <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-6 h-6" />
                  Next Rank: Grandmaster
               </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
               <div className="flex justify-between font-black text-2xl">
                  <span>Progress</span>
                  <span>92%</span>
               </div>
               <div className="h-4 bg-white/20 rounded-full overflow-hidden">
                  <div className="h-full bg-white w-[92%]" />
               </div>
               <p className="text-primary-foreground/80 font-medium">Almost there! Complete 4 more challenges this week to unlock the Grandmaster badge.</p>
            </CardContent>
         </Card>

         <Card className="rounded-3xl border-none shadow-xl bg-card">
            <CardHeader>
               <CardTitle className="flex items-center gap-2">
                  <Users className="w-6 h-6 text-primary" />
                  Your Stats
               </CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-4">
               <StatBox icon={<Zap className="w-4 h-4" />} label="Streak" value="14 Days" />
               <StatBox icon={<Target className="w-4 h-4" />} label="Accuracy" value="94%" />
               <StatBox icon={<Trophy className="w-4 h-4" />} label="Badges" value="28" />
               <StatBox icon={<TrendingUp className="w-4 h-4" />} label="Growth" value="+12%" />
            </CardContent>
         </Card>
      </div>
    </div>
  );
}

function LeaderboardItem({ rank, name, xp, trend, isUser = false }: { rank: number; name: string; xp: string; trend: 'up' | 'down' | 'stable'; isUser?: boolean }) {
  return (
    <div className={`flex items-center justify-between p-4 rounded-2xl transition-all border ${isUser ? 'bg-primary/5 border-primary shadow-sm' : 'bg-card hover:border-muted-foreground/30'}`}>
       <div className="flex items-center gap-5">
          <span className={`w-8 font-black text-xl text-center ${rank <= 3 ? 'text-primary' : 'text-muted-foreground/50'}`}>{rank}</span>
          <Avatar className="w-12 h-12 border shadow-sm">
             <AvatarImage src={`https://picsum.photos/seed/${name}/100/100`} />
             <AvatarFallback>{name[0]}</AvatarFallback>
          </Avatar>
          <div>
             <p className={`font-bold text-lg leading-tight ${isUser ? 'text-primary' : ''}`}>{name}</p>
             <p className="text-xs font-black text-muted-foreground uppercase tracking-widest">{xp} XP</p>
          </div>
       </div>
       <div className="flex items-center gap-4">
          <div className={`text-xs font-black uppercase tracking-widest px-2 py-1 rounded bg-secondary`}>Diamond</div>
          {trend === 'up' && <TrendingUp className="w-5 h-5 text-emerald-500" />}
          {trend === 'down' && <TrendingUp className="w-5 h-5 text-red-500 rotate-180" />}
          {trend === 'stable' && <div className="w-5 h-1 bg-muted-foreground/20 rounded-full" />}
       </div>
    </div>
  );
}

function StatBox({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="p-4 rounded-2xl bg-secondary/50 border space-y-1">
       <div className="flex items-center gap-2 text-muted-foreground">
          {icon}
          <span className="text-xs font-bold uppercase tracking-wider">{label}</span>
       </div>
       <div className="text-xl font-black">{value}</div>
    </div>
  );
}