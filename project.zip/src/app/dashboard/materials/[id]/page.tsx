
"use client";

import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  FileText, 
  Sparkles, 
  Layers, 
  Brain, 
  Trophy, 
  ChevronLeft, 
  ChevronRight, 
  CheckCircle2,
  ListTodo,
  Video,
  Loader2
} from "lucide-react";
import Link from "next/link";
import { generateEducationalVideo } from "@/ai/flows/generate-educational-video";
import { useToast } from "@/hooks/use-toast";

export default function MaterialAnalysisPage() {
  const [flashcardIndex, setFlashcardIndex] = useState(0);
  const [showDefinition, setShowDefinition] = useState(false);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [isGeneratingVideo, setIsGeneratingVideo] = useState(false);
  const { toast } = useToast();

  const flashcards = [
    { term: "Photosynthesis", definition: "Process by which plants convert light energy into chemical energy." },
    { term: "Chlorophyll", definition: "Green pigment responsible for light absorption in plants." },
    { term: "ATP", definition: "Primary energy currency of the cell." },
  ];

  const handleGenerateVideo = async () => {
    setIsGeneratingVideo(true);
    setVideoUrl(null);
    try {
      const result = await generateEducationalVideo({ topic: "Cell Structure and Organelles" });
      setVideoUrl(result.videoDataUri);
      toast({
        title: "Video Ready!",
        description: "AI has generated an educational video for this topic.",
      });
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Generation Failed",
        description: error.message || "Failed to generate video. Please try again.",
      });
    } finally {
      setIsGeneratingVideo(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" className="rounded-full" asChild>
          <Link href="/dashboard/materials">
            <ChevronLeft className="w-6 h-6" />
          </Link>
        </Button>
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight">Biology: Cell Structure</h1>
          <p className="text-muted-foreground font-medium">Analyzed from Cells_Lecture_Notes.pdf</p>
        </div>
      </div>

      <Tabs defaultValue="guide" className="w-full">
         <TabsList className="bg-secondary rounded-2xl p-1.5 h-16 w-full flex">
           <TabsTrigger value="guide" className="flex-1 rounded-xl font-black h-12 data-[state=active]:bg-white data-[state=active]:shadow-md gap-2">
              <FileText className="w-4 h-4" />
              Study Guide
           </TabsTrigger>
           <TabsTrigger value="flashcards" className="flex-1 rounded-xl font-black h-12 data-[state=active]:bg-white data-[state=active]:shadow-md gap-2">
              <Layers className="w-4 h-4" />
              Flashcards
           </TabsTrigger>
           <TabsTrigger value="video" className="flex-1 rounded-xl font-black h-12 data-[state=active]:bg-white data-[state=active]:shadow-md gap-2">
              <Video className="w-4 h-4" />
              AI Video
           </TabsTrigger>
           <TabsTrigger value="quiz" className="flex-1 rounded-xl font-black h-12 data-[state=active]:bg-white data-[state=active]:shadow-md gap-2">
              <Brain className="w-4 h-4" />
              AI Quiz
           </TabsTrigger>
         </TabsList>

         <TabsContent value="guide" className="mt-8">
            <div className="grid md:grid-cols-3 gap-8">
               <div className="md:col-span-2 space-y-8">
                  <Card className="rounded-3xl border-none shadow-sm ring-1 ring-border p-8 prose prose-slate max-w-none">
                     <h2 className="text-2xl font-black text-primary mb-4 flex items-center gap-2">
                        <Sparkles className="w-6 h-6" />
                        AI Summary
                     </h2>
                     <p className="text-lg leading-relaxed font-medium">
                        This document covers the fundamental structures of eukaryotic cells, specifically focusing on organelles and their metabolic functions.
                     </p>
                     
                     <h2 className="text-2xl font-black text-primary mt-12 mb-4">Key Concepts</h2>
                     <ul className="space-y-4 list-none p-0">
                        <li className="bg-secondary/50 p-4 rounded-2xl border flex gap-4">
                           <div className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center font-black shrink-0">1</div>
                           <div>
                              <p className="font-bold text-lg">Mitochondria: The Powerhouse</p>
                              <p className="text-muted-foreground font-medium">Responsible for ATP production through cellular respiration.</p>
                           </div>
                        </li>
                     </ul>
                  </Card>
               </div>
               
               <div className="space-y-6">
                  <Card className="rounded-3xl border-none shadow-sm ring-1 ring-border bg-accent text-white overflow-hidden">
                     <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                           <Trophy className="w-5 h-5" />
                           Quick Review
                        </CardTitle>
                     </CardHeader>
                     <CardContent className="space-y-4">
                        <p className="font-medium opacity-90 italic">&quot;A cell is the smallest unit of life capable of reproduction.&quot;</p>
                     </CardContent>
                  </Card>
               </div>
            </div>
         </TabsContent>

         <TabsContent value="flashcards" className="mt-8 flex flex-col items-center">
            <div 
               className={`w-full max-w-2xl aspect-[16/10] perspective-1000 cursor-pointer group`}
               onClick={() => setShowDefinition(!showDefinition)}
            >
               <div className={`relative w-full h-full transition-all duration-500 preserve-3d ${showDefinition ? 'rotate-y-180' : ''}`}>
                  <div className="absolute inset-0 bg-white rounded-[3rem] shadow-2xl border-4 border-primary/10 flex flex-col items-center justify-center p-12 backface-hidden">
                     <p className="text-xs font-black text-muted-foreground uppercase tracking-[0.3em] mb-4">Term</p>
                     <h3 className="text-4xl lg:text-5xl font-black text-center">{flashcards[flashcardIndex].term}</h3>
                  </div>
                  <div className="absolute inset-0 bg-primary text-white rounded-[3rem] shadow-2xl flex flex-col items-center justify-center p-12 backface-hidden rotate-y-180">
                     <p className="text-xs font-black text-white/60 uppercase tracking-[0.3em] mb-4">Definition</p>
                     <p className="text-2xl lg:text-3xl font-bold text-center leading-relaxed">{flashcards[flashcardIndex].definition}</p>
                  </div>
               </div>
            </div>
         </TabsContent>

         <TabsContent value="video" className="mt-8 flex flex-col items-center">
            <Card className="w-full max-w-4xl rounded-[2.5rem] border-none shadow-2xl overflow-hidden bg-white">
               <div className="p-8 space-y-6">
                  <div className="flex items-center justify-between">
                     <div>
                        <h3 className="text-2xl font-black">AI Educational Video</h3>
                        <p className="text-muted-foreground font-medium">Generate a custom visual lesson for this material.</p>
                     </div>
                     {!videoUrl && !isGeneratingVideo && (
                        <Button 
                           onClick={handleGenerateVideo} 
                           className="rounded-2xl h-14 px-8 font-black gap-2 shadow-lg shadow-primary/20"
                        >
                           <Video className="w-5 h-5" />
                           Generate with Veo
                        </Button>
                     )}
                  </div>

                  {isGeneratingVideo && (
                     <div className="aspect-video bg-secondary rounded-3xl flex flex-col items-center justify-center space-y-4">
                        <Loader2 className="w-12 h-12 animate-spin text-primary" />
                        <div className="text-center">
                           <p className="font-black text-lg">Creating your video...</p>
                           <p className="text-sm text-muted-foreground">Veo is animating the concepts. This can take up to a minute.</p>
                        </div>
                     </div>
                  )}

                  {videoUrl && (
                     <div className="aspect-video bg-black rounded-3xl overflow-hidden shadow-2xl">
                        <video 
                           src={videoUrl} 
                           controls 
                           className="w-full h-full"
                           poster="https://picsum.photos/seed/videoposter/800/450"
                        />
                     </div>
                  )}

                  {!videoUrl && !isGeneratingVideo && (
                     <div className="aspect-video bg-secondary/50 border-4 border-dashed rounded-3xl flex flex-col items-center justify-center text-muted-foreground">
                        <Video className="w-16 h-16 mb-4 opacity-20" />
                        <p className="font-bold">No video generated yet.</p>
                     </div>
                  )}
               </div>
            </Card>
         </TabsContent>

         <TabsContent value="quiz" className="mt-8 flex flex-col items-center">
             <Card className="w-full max-w-3xl rounded-[2.5rem] border-none shadow-2xl p-10 space-y-8 bg-white">
                <div className="space-y-2">
                   <h3 className="text-2xl font-bold leading-tight">Which organelle is primarily responsible for protein synthesis?</h3>
                </div>
                <div className="grid gap-4">
                   <button className="w-full text-left p-6 rounded-2xl border-2 font-bold text-lg transition-all hover:border-primary hover:bg-primary/5">Ribosome</button>
                   <button className="w-full text-left p-6 rounded-2xl border-2 font-bold text-lg transition-all hover:border-primary hover:bg-primary/5">Mitochondria</button>
                </div>
             </Card>
         </TabsContent>
      </Tabs>

      <style jsx global>{`
         .perspective-1000 { perspective: 1000px; }
         .preserve-3d { transform-style: preserve-3d; }
         .backface-hidden { backface-visibility: hidden; }
         .rotate-y-180 { transform: rotateY(180deg); }
      `}</style>
    </div>
  );
}
