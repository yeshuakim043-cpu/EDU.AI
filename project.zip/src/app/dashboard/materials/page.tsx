"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Upload, 
  FileText, 
  Link as LinkIcon, 
  Youtube, 
  Image as ImageIcon, 
  Plus, 
  Search, 
  Filter, 
  MoreVertical,
  Brain,
  Sparkles,
  Loader2
} from "lucide-react";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";
import { summarizeAndExtractKeyConcepts } from "@/ai/flows/summarize-and-extract-key-concepts";
import { generateStudyTools } from "@/ai/flows/generate-study-tools-from-content";

export default function MaterialsPage() {
  const [isUploading, setIsUploading] = useState(false);
  const { toast } = useToast();

  const handleSimulateUpload = async () => {
    setIsUploading(true);
    try {
      // Simulate real processing for demo purposes
      // In a real app, this would use the user's file content
      const demoContent = "Photosynthesis is a process used by plants and other organisms to convert light energy into chemical energy that, through cellular respiration, can later be released to fuel the organism's activities. This chemical energy is stored in carbohydrate molecules, such as sugars and starches, which are synthesized from carbon dioxide and water.";
      
      const summary = await summarizeAndExtractKeyConcepts({ documentContent: demoContent });
      const tools = await generateStudyTools({ textContent: demoContent });

      console.log("AI Results:", { summary, tools });

      toast({
        title: "Material Processed!",
        description: "AI has generated your study guide, flashcards, and quiz.",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Processing Failed",
        description: "Something went wrong with the AI analysis.",
      });
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight">Your Materials</h1>
          <p className="text-muted-foreground font-medium mt-1">Manage all your uploaded documents and links.</p>
        </div>
        <div className="flex gap-2">
           <Button variant="outline" className="rounded-xl font-bold h-11 border-2">
              <Filter className="w-4 h-4 mr-2" />
              Filter
           </Button>
           <Button className="rounded-xl font-bold h-11 shadow-lg shadow-primary/20" onClick={handleSimulateUpload} disabled={isUploading}>
              {isUploading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Plus className="w-4 h-4 mr-2" />}
              {isUploading ? "AI Processing..." : "New Material"}
           </Button>
        </div>
      </div>

      <div className="grid md:grid-cols-4 gap-4">
        <UploadBox icon={<FileText className="w-5 h-5" />} label="PDF / Doc" color="bg-blue-50 text-blue-600" />
        <UploadBox icon={<ImageIcon className="w-5 h-5" />} label="Screenshot" color="bg-orange-50 text-orange-600" />
        <UploadBox icon={<Youtube className="w-5 h-5" />} label="YouTube Link" color="bg-red-50 text-red-600" />
        <UploadBox icon={<LinkIcon className="w-5 h-5" />} label="Web Page" color="bg-purple-50 text-purple-600" />
      </div>

      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <Input placeholder="Search your materials..." className="pl-12 h-14 rounded-2xl bg-card border-none shadow-sm ring-1 ring-border text-lg" />
      </div>

      <div className="space-y-4">
        <MaterialListItem 
           title="Biology: Cell Structure"
           type="PDF"
           date="Uploaded 2 hours ago"
           status="Analyzed"
           badgeColor="bg-emerald-100 text-emerald-700"
        />
        <MaterialListItem 
           title="Advanced Calculus: Integrals"
           type="Document"
           date="Uploaded Yesterday"
           status="Analyzed"
           badgeColor="bg-emerald-100 text-emerald-700"
        />
        <MaterialListItem 
           title="Spanish Vocabulary Set 4"
           type="Image"
           date="Uploaded 3 days ago"
           status="Pending AI"
           badgeColor="bg-amber-100 text-amber-700"
        />
      </div>
    </div>
  );
}

function UploadBox({ icon, label, color }: { icon: React.ReactNode; label: string; color: string }) {
  return (
    <button className="p-6 rounded-2xl bg-card border border-dashed border-border hover:border-primary hover:bg-primary/5 transition-all flex flex-col items-center gap-3 group">
       <div className={`${color} w-12 h-12 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform`}>
          {icon}
       </div>
       <span className="text-sm font-bold text-muted-foreground group-hover:text-primary">{label}</span>
    </button>
  );
}

function MaterialListItem({ title, type, date, status, badgeColor }: { title: string; type: string; date: string; status: string; badgeColor: string }) {
  return (
    <div className="group flex items-center justify-between p-5 rounded-2xl bg-card border shadow-sm hover:shadow-md hover:border-primary/30 transition-all cursor-pointer">
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-xl bg-secondary flex items-center justify-center text-primary border">
           <FileText className="w-6 h-6" />
        </div>
        <div className="space-y-1">
          <h4 className="font-bold text-lg group-hover:text-primary transition-colors">{title}</h4>
          <div className="flex items-center gap-3 text-sm font-medium text-muted-foreground">
             <span>{type}</span>
             <span className="w-1 h-1 rounded-full bg-muted-foreground/30" />
             <span>{date}</span>
          </div>
        </div>
      </div>
      <div className="flex items-center gap-4">
         <div className={`px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider flex items-center gap-1.5 ${badgeColor}`}>
            <Sparkles className="w-3 h-3" />
            {status}
         </div>
         <DropdownMenu>
           <DropdownMenuTrigger asChild>
             <Button variant="ghost" size="icon" className="rounded-full">
                <MoreVertical className="w-5 h-5" />
             </Button>
           </DropdownMenuTrigger>
           <DropdownMenuContent align="end" className="rounded-xl w-48 font-medium">
             <DropdownMenuItem className="p-3 cursor-pointer">View Analysis</DropdownMenuItem>
             <DropdownMenuItem className="p-3 cursor-pointer">Practice Quiz</DropdownMenuItem>
             <DropdownMenuItem className="p-3 cursor-pointer">Rename</DropdownMenuItem>
             <DropdownMenuItem className="p-3 cursor-pointer text-destructive font-bold">Delete</DropdownMenuItem>
           </DropdownMenuContent>
         </DropdownMenu>
      </div>
    </div>
  );
}