"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Trophy, 
  Target, 
  Layers, 
  Brain, 
  FileText, 
  ChevronRight,
  Sparkles,
  Zap,
  Star,
  TrendingUp,
  Clock
} from "lucide-react";
import Link from "next/link";
import { useUser } from "@/firebase";

export default function DashboardPage() {
  const { user } = useUser();

  return (
    <div className="max-w-7xl mx-auto space-y-10 py-4 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-5xl font-black tracking-tight bg-gradient-to-r from-white via-white to-white/40 bg-clip-text text-transparent">
            Dashboard
          </h1>
          <p className="text-muted-foreground font-medium mt-2 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-primary animate-pulse" />
            Welcome back, <span className="text-white font-bold">{user?.displayName || "Jane Doe"}</span>
          </p>
        </div>
        <div className="flex items-center gap-3 bg-white/5 p-2 rounded-2xl border border-white/5">
           <div className="bg-primary/20 p-3 rounded-xl border border-primary/20">
              <Clock className="w-5 h-5 text-primary" />
           </div>
           <div>
              <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Study Session</p>
              <p className="text-sm font-bold">2h 15m today</p>
           </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-2 glass-card border-none overflow-hidden relative group neon-glow-primary rounded-[2.5rem]">
          <div className="absolute top-0 right-0 w-96 h-96 bg-primary/20 blur-[120px] -z-10 group-hover:bg-primary/30 transition-colors duration-700" />
          <CardHeader className="pb-2 pt-10 px-10">
            <CardTitle className="text-2xl font-black flex items-center gap-3">
              <Target className="w-6 h-6 text-accent" />
              Weekly Progress
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-10 p-10">
            <div className="space-y-6">
              <div className="flex justify-between items-end">
                <div>
                   <span className="text-xs font-black text-white/50 uppercase tracking-[0.2em]">Knowledge Mastery</span>
                   <p className="text-4xl font-black text-white mt-1">85<span className="text-accent">%</span></p>
                </div>
                <div className="text-right">
                   <span className="text-xs font-black text-emerald-500 uppercase tracking-[0.2em] flex items-center justify-end gap-1">
                      <TrendingUp className="w-3 h-3" />
                      +12% this week
                   </span>
                </div>
              </div>
              <div className="relative h-5 w-full bg-white/5 rounded-full overflow-hidden border border-white/5 shadow-inner">
                <div 
                  className="absolute top-0 left-0 h-full bg-gradient-to-r from-primary to-accent shadow-[0_0_30px_rgba(147,51,234,0.6)] transition-all duration-1000 ease-out" 
                  style={{ width: '85%' }}
                />
              </div>
              <div className="flex justify-between text-[10px] font-black text-muted-foreground uppercase tracking-[0.3em]">
                <span>1,250 XP EARNED</span>
                <span>450 XP TO NEXT LEVEL</span>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 pt-6">
               <StatItem icon={<Zap className="w-5 h-5 text-orange-500" />} label="Streak" value="14 Days" />
               <StatItem icon={<Brain className="w-5 h-5 text-primary" />} label="Quizzes" value="28" />
               <StatItem icon={<FileText className="w-5 h-5 text-accent" />} label="Files" value="12" />
               <StatItem icon={<Trophy className="w-5 h-5 text-yellow-400" />} label="Rank" value="#4" />
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-none overflow-hidden flex flex-col justify-between p-10 rounded-[2.5rem]">
           <CardHeader className="p-0 text-center space-y-2">
              <CardTitle className="text-xl font-black flex items-center justify-center gap-3">
                 <Trophy className="w-6 h-6 text-yellow-400" />
                 Global Ranking
              </CardTitle>
              <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Master League</p>
           </CardHeader>
           <CardContent className="p-0 space-y-8 mt-8">
              <div className="flex justify-center items-end gap-6 h-40">
                 <PodiumBar height="h-20" rank="2" color="bg-slate-400/50" label="S. Jenkins" />
                 <PodiumBar height="h-32" rank="1" color="bg-yellow-400" active label="M. Lee" />
                 <PodiumBar height="h-16" rank="3" color="bg-orange-600/50" label="L. Garcia" />
              </div>
              <div className="text-center bg-white/5 p-6 rounded-3xl border border-white/5">
                 <p className="text-sm font-bold text-white/80">You are currently <span className="text-primary font-black">4th</span></p>
                 <p className="text-[10px] font-black text-muted-foreground mt-2 uppercase tracking-widest">150 XP TO TOP 3</p>
              </div>
              <Button variant="outline" className="w-full h-14 rounded-2xl border-white/10 hover:bg-white/5 font-black text-xs uppercase tracking-widest" asChild>
                 <Link href="/dashboard/leaderboards">View Full Hall of Fame</Link>
              </Button>
           </CardContent>
        </Card>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        <ActionCard 
          icon={<Layers className="w-8 h-8 text-primary" />} 
          title="Flashcards" 
          description="Master complex terminology with AI-generated interactive decks."
          color="hover:border-primary/50"
          glowColor="rgba(147, 51, 234, 0.2)"
          href="/dashboard/materials"
        />
        <ActionCard 
          icon={<Brain className="w-8 h-8 text-accent" />} 
          title="Adaptive Quizzes" 
          description="Test your retention with custom tests that adapt to your weaknesses."
          color="hover:border-accent/50"
          glowColor="rgba(0, 210, 255, 0.2)"
          href="/dashboard/materials"
        />
        <ActionCard 
          icon={<FileText className="w-8 h-8 text-white" />} 
          title="Study Guides" 
          description="Generate structured summaries and key concept lists instantly."
          color="hover:border-white/30"
          glowColor="rgba(255, 255, 255, 0.1)"
          href="/dashboard/materials"
        />
      </div>
    </div>
  );
}

function StatItem({ icon, label, value }: any) {
  return (
    <div className="p-5 rounded-3xl bg-white/5 border border-white/5 text-center space-y-2 hover:bg-white/10 transition-colors">
      <div className="flex justify-center mb-1">{icon}</div>
      <div className="text-xl font-black text-white">{value}</div>
      <div className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">{label}</div>
    </div>
  );
}

function PodiumBar({ height, rank, color, active = false, label }: any) {
  return (
    <div className="flex flex-col items-center gap-3 group">
      <div className={`w-14 ${height} ${color} rounded-t-2xl relative flex items-center justify-center ${active ? 'shadow-[0_0_40px_rgba(250,204,21,0.3)]' : ''}`}>
        <span className="font-black text-black/50 text-2xl">{rank}</span>
      </div>
      <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">{label}</p>
    </div>
  );
}

function ActionCard({ icon, title, description, color, glowColor, href }: any) {
  return (
    <Link href={href} className="block group">
      <Card className={`glass-card border-white/5 transition-all duration-500 h-full action-card-gradient ${color} group-hover:-translate-y-3 rounded-[2.5rem]`}>
        <CardContent className="p-10 space-y-6">
          <div className="p-4 bg-white/5 w-fit rounded-2xl border border-white/10 group-hover:scale-110 transition-transform duration-500 shadow-xl">
            {icon}
          </div>
          <div className="space-y-3">
            <h3 className="text-3xl font-black text-white">{title}</h3>
            <p className="text-sm text-muted-foreground font-medium leading-relaxed">{description}</p>
          </div>
          <div className="pt-6 flex items-center text-[10px] font-black uppercase tracking-[0.3em] text-primary group-hover:text-accent transition-colors">
            Start Learning
            <ChevronRight className="w-4 h-4 ml-2 group-hover:translate-x-2 transition-transform" />
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}