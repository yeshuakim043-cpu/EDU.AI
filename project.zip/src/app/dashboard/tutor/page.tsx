"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Send, Sparkles, Brain, GraduationCap, Languages, Mic, Volume2, Info } from "lucide-react";

export default function TutorPage() {
  const [messages, setMessages] = useState([
    { 
      role: 'assistant', 
      content: "Hi Jane! I'm your EDU.AI Tutor. I've analyzed your recent Physics quiz and noticed you had some trouble with 'Projectile Motion'. Would you like to review that together, or start something new?",
      time: "9:00 AM"
    }
  ]);
  const [input, setInput] = useState("");

  const handleSend = () => {
    if (!input.trim()) return;
    const newMsg = { role: 'user', content: input, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) };
    setMessages([...messages, newMsg]);
    setInput("");
    
    // Simulate AI thinking and response
    setTimeout(() => {
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: "That's a great question! Projectile motion is essentially motion in two dimensions. Let's break it down into its horizontal and vertical components. Which part should we look at first?",
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }]);
    }, 1000);
  };

  return (
    <div className="max-w-6xl mx-auto h-[calc(100vh-12rem)] flex gap-8">
      {/* Sidebar Controls */}
      <div className="w-80 hidden lg:flex flex-col gap-6 shrink-0">
        <Card className="rounded-2xl border-none shadow-sm ring-1 ring-border">
          <CardHeader>
            <CardTitle className="text-lg">Tutor Mode</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
             <TutorModeButton icon={<Brain className="w-4 h-4" />} label="Study Assistant" active />
             <TutorModeButton icon={<GraduationCap className="w-4 h-4" />} label="Concept Explainer" />
             <TutorModeButton icon={<Languages className="w-4 h-4" />} label="Language Partner" />
          </CardContent>
        </Card>

        <Card className="rounded-2xl border-none shadow-sm ring-1 ring-border bg-primary/5">
           <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                 <Sparkles className="w-4 h-4 text-primary" />
                 Context
              </CardTitle>
           </CardHeader>
           <CardContent className="space-y-4">
              <div className="p-3 bg-white rounded-xl border text-sm font-medium shadow-sm">
                 <p className="text-muted-foreground text-xs uppercase mb-1 font-black tracking-widest">Currently Studying</p>
                 <p>AP Physics: Unit 3</p>
              </div>
              <div className="p-3 bg-white rounded-xl border text-sm font-medium shadow-sm">
                 <p className="text-muted-foreground text-xs uppercase mb-1 font-black tracking-widest">Focus Areas</p>
                 <ul className="space-y-1">
                    <li className="flex items-center gap-2">
                       <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                       Horizontal Velocity
                    </li>
                    <li className="flex items-center gap-2">
                       <div className="w-1.5 h-1.5 rounded-full bg-accent" />
                       Gravity Acceleration
                    </li>
                 </ul>
              </div>
           </CardContent>
        </Card>
      </div>

      {/* Main Chat Interface */}
      <Card className="flex-1 rounded-3xl overflow-hidden border-none shadow-xl flex flex-col bg-card">
         <div className="p-6 border-b flex items-center justify-between bg-card">
            <div className="flex items-center gap-4">
               <div className="relative">
                  <Avatar className="w-12 h-12 border-2 border-primary shadow-sm">
                     <AvatarImage src="https://picsum.photos/seed/tutor/100/100" />
                     <AvatarFallback>AI</AvatarFallback>
                  </Avatar>
                  <div className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 rounded-full border-2 border-white" />
               </div>
               <div>
                  <h3 className="font-black text-lg leading-tight">EDU.AI Tutor</h3>
                  <p className="text-xs font-black text-primary uppercase tracking-widest">Online • Thinking Fast</p>
               </div>
            </div>
            <div className="flex gap-2">
               <Button variant="ghost" size="icon" className="rounded-full">
                  <Volume2 className="w-5 h-5 text-muted-foreground" />
               </Button>
               <Button variant="ghost" size="icon" className="rounded-full">
                  <Info className="w-5 h-5 text-muted-foreground" />
               </Button>
            </div>
         </div>

         <ScrollArea className="flex-1 p-6">
            <div className="space-y-6 max-w-4xl mx-auto">
               {messages.map((msg, i) => (
                  <div key={i} className={`flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                     <Avatar className="w-10 h-10 border shadow-sm">
                        <AvatarImage src={msg.role === 'assistant' ? "https://picsum.photos/seed/tutor/100/100" : "https://picsum.photos/seed/user1/100/100"} />
                        <AvatarFallback>{msg.role === 'assistant' ? 'AI' : 'JD'}</AvatarFallback>
                     </Avatar>
                     <div className={`space-y-1 max-w-[80%] ${msg.role === 'user' ? 'items-end' : ''}`}>
                        <div className={`p-4 rounded-2xl shadow-sm text-sm font-medium leading-relaxed ${msg.role === 'user' ? 'bg-primary text-white rounded-tr-none' : 'bg-secondary rounded-tl-none'}`}>
                           {msg.content}
                        </div>
                        <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest px-1">
                           {msg.time}
                        </p>
                     </div>
                  </div>
               ))}
            </div>
         </ScrollArea>

         <div className="p-6 bg-secondary/30 border-t">
            <div className="max-w-4xl mx-auto relative group">
               <Input 
                  placeholder="Ask anything about your materials..." 
                  className="h-16 pr-32 pl-6 rounded-2xl bg-background border-none shadow-lg text-lg ring-1 ring-border group-focus-within:ring-primary transition-all"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSend()}
               />
               <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-2">
                  <Button variant="ghost" size="icon" className="rounded-xl h-11 w-11 hover:bg-secondary">
                     <Mic className="w-5 h-5 text-muted-foreground" />
                  </Button>
                  <Button 
                    className="rounded-xl h-11 w-11 shadow-lg shadow-primary/20"
                    onClick={handleSend}
                  >
                     <Send className="w-5 h-5" />
                  </Button>
               </div>
            </div>
            <p className="text-center text-[10px] text-muted-foreground mt-4 font-bold uppercase tracking-widest opacity-50">
               EDU.AI can make mistakes. Verify important information.
            </p>
         </div>
      </Card>
    </div>
  );
}

function TutorModeButton({ icon, label, active = false }: { icon: React.ReactNode; label: string; active?: boolean }) {
  return (
    <Button 
      variant={active ? "default" : "ghost"} 
      className={`w-full justify-start gap-3 rounded-xl h-11 font-bold ${active ? 'shadow-lg shadow-primary/20' : ''}`}
    >
      {icon}
      {label}
    </Button>
  );
}
