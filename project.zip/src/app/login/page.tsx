"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { BrainCircuit, Loader2, AlertCircle, Sparkles } from "lucide-react";
import { useAuth } from "@/firebase";
import { signInWithEmailAndPassword, signInWithPopup, GoogleAuthProvider } from "firebase/auth";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const auth = useAuth();
  const router = useRouter();
  const { toast } = useToast();

  const isConfigured = !!auth && !!process.env.NEXT_PUBLIC_FIREBASE_API_KEY;

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth) return;
    
    setLoading(true);
    try {
      await signInWithEmailAndPassword(auth, email, password);
      toast({
        title: "Welcome back!",
        description: "Successfully logged in to EDU.AI.",
      });
      router.push("/dashboard");
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Login failed",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    if (!auth) return;
    setLoading(true);
    try {
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ prompt: 'select_account' });
      await signInWithPopup(auth, provider);
      toast({
        title: "Success",
        description: "Logged in with Google",
      });
      router.push("/dashboard");
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Google Sign-in failed",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background relative overflow-hidden">
      {/* Background elements for high-end feel */}
      <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_50%_-20%,hsl(var(--primary)/0.2),transparent_50%)]" />
      <div className="absolute -bottom-20 -right-20 w-96 h-96 bg-accent/10 rounded-full blur-[100px]" />
      
      <div className="w-full max-w-[440px] space-y-10 relative z-10 animate-in fade-in zoom-in-95 duration-500">
        <div className="flex flex-col items-center text-center space-y-4">
          <Link href="/" className="bg-primary p-4 rounded-3xl text-white mb-4 shadow-[0_0_30px_rgba(147,51,234,0.5)] hover:scale-110 transition-transform duration-500">
            <BrainCircuit className="w-10 h-10" />
          </Link>
          <h1 className="text-5xl font-black tracking-tighter text-white">EDU.AI</h1>
          <p className="text-muted-foreground font-medium italic">Your personalized learning ecosystem awaits.</p>
        </div>

        {!isConfigured && (
          <Alert variant="destructive" className="bg-destructive/10 border-destructive/20 text-destructive rounded-2xl">
            <AlertCircle className="h-5 w-5" />
            <AlertTitle className="font-black uppercase tracking-widest text-[10px]">Configuration Missing</AlertTitle>
            <AlertDescription className="text-xs font-medium">
              Firebase is not yet configured. Please add your API keys to get started.
            </AlertDescription>
          </Alert>
        )}

        <div className="glass-card p-10 rounded-[3rem] border-white/5 space-y-8">
          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-[10px] font-black uppercase tracking-widest ml-1 text-muted-foreground">Email Address</Label>
              <Input 
                id="email" 
                type="email" 
                placeholder="name@example.com" 
                className="h-14 bg-white/5 border-white/10 rounded-2xl focus:ring-primary focus:border-primary text-lg" 
                required
                disabled={!auth || loading}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between ml-1">
                <Label htmlFor="password" title="Password" className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Password</Label>
                <Link href="#" className="text-[10px] font-black uppercase tracking-widest text-primary hover:text-accent transition-colors">Forgot?</Link>
              </div>
              <Input 
                id="password" 
                type="password" 
                className="h-14 bg-white/5 border-white/10 rounded-2xl focus:ring-primary focus:border-primary text-lg" 
                required
                disabled={!auth || loading}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            <Button 
              className="w-full h-14 text-lg font-black rounded-2xl shadow-xl shadow-primary/30 transition-all active:scale-95" 
              type="submit" 
              disabled={!auth || loading}
            >
              {loading ? <Loader2 className="w-6 h-6 animate-spin mr-2" /> : "Sign In"}
            </Button>
            
            <div className="relative my-8">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t border-white/10" />
              </div>
              <div className="relative flex justify-center text-[10px] uppercase font-black tracking-[0.4em]">
                <span className="bg-[#0a0a0c] px-4 text-muted-foreground">Or Connect</span>
              </div>
            </div>

            <Button 
              variant="outline" 
              type="button" 
              className="w-full h-14 gap-3 font-black text-xs uppercase tracking-widest rounded-2xl border-white/10 hover:bg-white/5 transition-all" 
              onClick={handleGoogleSignIn}
              disabled={!auth || loading}
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="currentColor" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="currentColor" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" />
                <path fill="currentColor" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
              </svg>
              Google Account
            </Button>
          </form>
        </div>

        <p className="text-center text-sm text-muted-foreground font-medium">
          New to EDU.AI?{" "}
          <Link href="/signup" className="font-black text-primary hover:text-accent transition-colors underline underline-offset-8">Create Account</Link>
        </p>
      </div>
    </div>
  );
}