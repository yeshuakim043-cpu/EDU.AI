import Link from "next/link";
import Image from "next/image";
import { Navbar } from "@/components/navbar";
import { Button } from "@/components/ui/button";
import { 
  ArrowRight, 
  Sparkles, 
  Zap, 
  Users, 
  Trophy, 
  BookOpen,
  Languages,
  BrainCircuit
} from "lucide-react";
import { PlaceHolderImages } from "@/lib/placeholder-images";

export default function Home() {
  const heroImage = PlaceHolderImages.find(img => img.id === "hero-student");
  const fallbackUrl = "https://picsum.photos/seed/fallback/1200/800";

  return (
    <div className="min-h-screen">
      <Navbar />
      
      <section className="pt-32 pb-20 px-4">
        <div className="container mx-auto grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-semibold">
              <Sparkles className="w-4 h-4" />
              <span>AI-Powered Education is Here</span>
            </div>
            <h1 className="text-5xl lg:text-7xl font-extrabold tracking-tight leading-tight">
              Master Anything with <span className="text-primary italic">EDU.AI</span>
            </h1>
            <p className="text-xl text-muted-foreground leading-relaxed max-w-lg">
              Upload your documents, notes, or links. Our AI transforms them into interactive flashcards, quizzes, and personalized study guides in seconds.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="h-14 px-8 text-lg rounded-xl group" asChild>
                <Link href="/signup">
                  Get Started for Free
                  <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="h-14 px-8 text-lg rounded-xl" asChild>
                <Link href="/login">Watch Demo</Link>
              </Button>
            </div>
          </div>
          <div className="relative">
            <div className="absolute -top-12 -left-12 w-64 h-64 bg-primary/20 rounded-full blur-3xl -z-10" />
            <div className="absolute -bottom-12 -right-12 w-64 h-64 bg-accent/20 rounded-full blur-3xl -z-10" />
            <div className="rounded-2xl overflow-hidden shadow-2xl border bg-background p-2">
              <Image 
                src={heroImage?.imageUrl || fallbackUrl} 
                alt={heroImage?.description || "Student studying"} 
                width={1200}
                height={800}
                className="rounded-xl w-full"
                data-ai-hint="student studying"
              />
            </div>
          </div>
        </div>
      </section>

      <section id="features" className="py-24 bg-secondary/30">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-20 space-y-4">
            <h2 className="text-4xl font-bold">One App. Every Subject.</h2>
            <p className="text-lg text-muted-foreground">
              EDU.AI is built for every type of learner, from STEM wizards to language enthusiasts.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <FeatureCard 
              icon={<Zap className="w-6 h-6 text-primary" />}
              title="Instant Study Tools"
              description="Convert PDFs, slides, and handwritten notes into flashcards and practice tests automatically."
            />
            <FeatureCard 
              icon={<BookOpen className="w-6 h-6 text-accent" />}
              title="Smart Note Taker"
              description="Record lectures or upload files. Get structured notes with key concepts highlighted for you."
            />
            <FeatureCard 
              icon={<Users className="w-6 h-6 text-purple-500" />}
              title="AI Classroom"
              description="Collaborate in shared study rooms, compete on leaderboards, and master subjects together."
            />
            <FeatureCard 
              icon={<Languages className="w-6 h-6 text-emerald-500" />}
              title="Language Master"
              description="Practice speaking and writing with AI tutors in 9+ languages with pronunciation analysis."
            />
          </div>
        </div>
      </section>

      <footer className="py-12 bg-background border-t">
        <div className="container mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-2">
            <BrainCircuit className="w-6 h-6 text-primary" />
            <span className="font-bold text-xl tracking-tight text-primary">EDU.AI</span>
          </div>
          <div className="flex gap-8 text-sm text-muted-foreground">
            <Link href="#" className="hover:text-primary">Privacy</Link>
            <Link href="#" className="hover:text-primary">Terms</Link>
            <Link href="#" className="hover:text-primary">Support</Link>
          </div>
          <p className="text-sm text-muted-foreground">© 2025 EDU.AI Inc. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <div className="p-8 rounded-2xl bg-card border hover:shadow-lg hover:border-primary/50 transition-all space-y-4">
      <div className="bg-background w-12 h-12 rounded-xl flex items-center justify-center shadow-sm border">
        {icon}
      </div>
      <h3 className="text-xl font-bold">{title}</h3>
      <p className="text-muted-foreground leading-relaxed">{description}</p>
    </div>
  );
}

function StatItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="text-center">
      <div className="text-3xl font-extrabold text-foreground mb-1">{value}</div>
      <div className="text-sm font-medium text-muted-foreground uppercase tracking-widest">{label}</div>
    </div>
  );
}
