"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { BrainCircuit, Loader2, AlertCircle, Sparkles } from "lucide-react";
import { useAuth, useFirestore } from "@/firebase";
import { createUserWithEmailAndPassword, updateProfile } from "firebase/auth";
import { doc, setDoc } from "firebase/firestore";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function SignupPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);
  const auth = useAuth();
  const db = useFirestore();
  const router = useRouter();
  const { toast } = useToast();

  const isConfigured = !!auth && !!db && !!process.env.NEXT_PUBLIC_FIREBASE_API_KEY;

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth || !db) return;
    
    setLoading(true);
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      await updateProfile(userCredential.user, { displayName: name });
      
      await setDoc(doc(db, "users", userCredential.user.uid), {
        uid: userCredential.user.uid,
        displayName: name,
        email: email,
        xp: 0,
        rank: "Bronze",
        streak: 0,
        createdAt: new Date().toISOString()
      });

      toast({
        title: "Account created!",
        description: "Welcome to EDU.AI.",
      });
      router.push("/dashboard");
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Signup failed",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_50%_-20%,hsl(var(--primary)/0.2),transparent_50%)]" />
      <div className="absolute -bottom-20 -left-20 w-96 h-96 bg-accent/10 rounded-full blur-[100px]" />

      <div className="w-full max-w-[440px] space-y-10 relative z-10 animate-in fade-in zoom-in-95 duration-500">
        <div className="flex flex-col items-center text-center space-y-4">
          <Link href="/" className="bg-primary p-4 rounded-3xl text-white mb-4 shadow-[0_0_30px_rgba(147,51,234,0.5)] hover:scale-110 transition-transform duration-500">
            <BrainCircuit className="w-10 h-10" />
          </Link>
          <h1 className="text-5xl font-black tracking-tighter text-white">JOIN EDU.AI</h1>
          <p className="text-muted-foreground font-medium italic">The future of intelligent learning begins here.</p>
        </div>

        {!isConfigured && (
          <Alert variant="destructive" className="bg-destructive/10 border-destructive/20 text-destructive rounded-2xl">
            <AlertCircle className="h-5 w-5" />
            <AlertTitle className="font-black uppercase tracking-widest text-[10px]">Configuration Missing</AlertTitle>
            <AlertDescription className="text-xs font-medium">
              Firebase is not yet configured. Please add your API keys to get started.
            </AlertDescription>
          </Alert>
        )}

        <div className="glass-card p-10 rounded-[3rem] border-white/5 space-y-8">
          <form onSubmit={handleSignup} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="name" className="text-[10px] font-black uppercase tracking-widest ml-1 text-muted-foreground">Full Name</Label>
              <Input 
                id="name" 
                placeholder="Jane Doe" 
                className="h-14 bg-white/5 border-white/10 rounded-2xl focus:ring-primary focus:border-primary text-lg" 
                required 
                disabled={!auth || loading}
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email" className="text-[10px] font-black uppercase tracking-widest ml-1 text-muted-foreground">Email Address</Label>
              <Input 
                id="email" 
                type="email" 
                placeholder="name@example.com" 
                className="h-14 bg-white/5 border-white/10 rounded-2xl focus:ring-primary focus:border-primary text-lg" 
                required 
                disabled={!auth || loading}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" title="Password" className="text-[10px] font-black uppercase tracking-widest ml-1 text-muted-foreground">Password</Label>
              <Input 
                id="password" 
                type="password" 
                className="h-14 bg-white/5 border-white/10 rounded-2xl focus:ring-primary focus:border-primary text-lg" 
                required 
                disabled={!auth || loading}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            <Button 
              className="w-full h-14 text-lg font-black rounded-2xl shadow-xl shadow-primary/30 transition-all active:scale-95 flex items-center gap-2" 
              type="submit" 
              disabled={!auth || loading}
            >
              {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : <Sparkles className="w-5 h-5" />}
              {loading ? "Creating..." : "Start Learning Free"}
            </Button>
          </form>
        </div>

        <p className="text-center text-sm text-muted-foreground font-medium">
          Already have an account?{" "}
          <Link href="/login" className="font-black text-primary hover:text-accent transition-colors underline underline-offset-8">Log in</Link>
        </p>
      </div>
    </div>
  );
}