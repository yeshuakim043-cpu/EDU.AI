'use client';

import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { getFirestore, Firestore } from 'firebase/firestore';
import { getAuth, Auth } from 'firebase/auth';
import { firebaseConfig } from './config';

export function initializeFirebase(): {
  app: FirebaseApp | undefined;
  firestore: Firestore | undefined;
  auth: Auth | undefined;
} {
  if (typeof window === 'undefined') {
    return { app: undefined, firestore: undefined, auth: undefined };
  }

  if (!firebaseConfig.apiKey) {
    return { app: undefined, firestore: undefined, auth: undefined };
  }

  try {
    const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
    const firestore = getFirestore(app);
    const auth = getAuth(app);
    return { app, firestore, auth };
  } catch (error) {
    console.error("Firebase failed to initialize:", error);
    return { app: undefined, firestore: undefined, auth: undefined };
  }
}

export * from './provider';
export * from './auth/use-user';
export * from './firestore/use-doc';
export * from './firestore/use-collection';